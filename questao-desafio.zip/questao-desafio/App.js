import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'O que a Psicologia estuda principalmente?',
    imagem: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600',
    opcoes: [
      'O clima',
      'O comportamento e os processos mentais',
      'Os planetas',
      'Os animais marinhos'
    ],
    respostaCerta: 1
  },
  {
    id: 2,
    pergunta: 'Qual área do cérebro está mais relacionada ao pensamento e à tomada de decisões?',
    imagem: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?w=600',
    opcoes: [
      'Pulmão',
      'Cerebelo',
      'Córtex pré-frontal',
      'Estômago'
    ],
    respostaCerta: 2
  },
  {
    id: 3,
    pergunta: 'O que é memória?',
    imagem: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600',
    opcoes: [
      'A capacidade de armazenar e recuperar informações',
      'A capacidade de correr rápido',
      'Um tipo de emoção',
      'Um reflexo do corpo'
    ],
    respostaCerta: 0
  },
  {
    id: 4,
    pergunta: 'Qual dos fatores abaixo pode influenciar o comportamento humano?',
    imagem: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600',
    opcoes: [
      'Apenas a genética',
      'Apenas o ambiente',
      'Genética e ambiente',
      'Apenas a alimentação'
    ],
    respostaCerta: 2
  },
  {
    id: 5,
    pergunta: 'O que é ansiedade?',
    imagem: 'https://images.unsplash.com/photo-1493836512294-502baa1986e2?w=600',
    opcoes: [
      'Uma sensação de preocupação ou medo diante de situações futuras',
      'Um tipo de inteligência',
      'Uma habilidade física',
      'Uma doença contagiosa'
    ],
    respostaCerta: 0
  },
  {
    id: 6,
    pergunta: 'Qual é a função das emoções?',
    imagem: 'https://images.unsplash.com/photo-1516302752625-fcc3c50ae61f?w=600',
    opcoes: [
      'Não possuem função',
      'Ajudam na adaptação e na tomada de decisões',
      'Servem apenas para causar problemas',
      'Existem somente na infância'
    ],
    respostaCerta: 1
  },
  {
    id: 7,
    pergunta: 'O que significa empatia?',
    imagem: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=600',
    opcoes: [
      'Ignorar os sentimentos dos outros',
      'Convencer alguém a mudar de ideia',
      'Compreender os sentimentos e perspectivas de outra pessoa',
      'Resolver problemas matemáticos'
    ],
    respostaCerta: 2
  },
  {
    id: 8,
    pergunta: 'O que é percepção?',
    imagem: 'https://images.unsplash.com/photo-1507146426996-ef05306b995a?w=600',
    opcoes: [
      'A forma como interpretamos as informações recebidas pelos sentidos',
      'A capacidade de dormir',
      'Um tipo de memória',
      'Uma emoção básica'
    ],
    respostaCerta: 0
  },
  {
    id: 9,
    pergunta: 'Qual é o objetivo principal da terapia psicológica?',
    imagem: 'https://images.unsplash.com/photo-1573497620053-ea5300f94f21?w=600',
    opcoes: [
      'Prescrever medicamentos',
      'Melhorar o bem-estar emocional e mental',
      'Aumentar a força física',
      'Ensinar matérias escolares'
    ],
    respostaCerta: 1
  },
  {
    id: 10,
    pergunta: 'O que é autoestima?',
    imagem: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600',
    opcoes: [
      'A opinião que uma pessoa tem sobre si mesma',
      'A opinião dos amigos sobre alguém',
      'Uma emoção temporária',
      'Um traço genético'
    ],
    respostaCerta: 0
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);
  const [botoesBloqueados, setBotoesBloqueados] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setOpcaoSelecionada(null);
    setBotoesBloqueados(false);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (botoesBloqueados) return;

    setOpcaoSelecionada(indiceClicado);
    setBotoesBloqueados(true);

    const pergunta = QUIZ[perguntaAtual];

    if (indiceClicado === pergunta.respostaCerta) {
      setPontuacao((valorAtual) => valorAtual + 1);
    }

    setTimeout(() => {
      setCarregando(true);

      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
          setOpcaoSelecionada(null);
          setBotoesBloqueados(false);
        } else {
          setTelaAtual('resultado');
        }

        setCarregando(false);
      }, 1500);
    }, 1000);
  }

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Image
          source={{
            uri: 'https://www.psicologosberrini.com.br/wp-content/uploads/servicos-de-psicologia-1017x1024.png'
          }}
          style={styles.logoInicial}
        />

        <Text style={styles.tituloPrincipal}>
          Quiz de Psicologia
        </Text>

        <Text style={styles.subtituloInicio}>
          Teste seus conhecimentos sobre Psicologia!
        </Text>

        <TouchableOpacity
          style={styles.botaoIniciar}
          onPress={iniciarJogo}
        >
          <Text style={styles.textoBotaoIniciar}>
            INICIAR QUIZ
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.titulo}>
          Quiz Finalizado!
        </Text>

        <Text style={styles.subtitulo}>
          Você acertou {pontuacao} de {QUIZ.length} perguntas.
        </Text>

        <TouchableOpacity
          style={styles.botaoAcao}
          onPress={voltarAoInicio}
        >
          <Text style={styles.textoBotaoAcao}>
            Voltar ao Início
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator
          size="large"
          color="#2563eb"
        />

        <Text style={styles.textoCarregando}>
          Validando resposta...
        </Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];

  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>
          Pergunta {perguntaAtual + 1} de {QUIZ.length}
        </Text>

        <Text style={styles.pontos}>
          Pontos: {pontuacao}
        </Text>
      </View>

      <View style={styles.cartaoPergunta}>
        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagemPergunta}
        />

        <Text style={styles.textoPergunta}>
          {pergunta.pergunta}
        </Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => {
          let estiloBotao = styles.botaoOpcao;

      
         if (opcaoSelecionada !== null && index === pergunta.respostaCerta) {
            estiloBotao = styles.botaoCorreto;
         }

        if (
           opcaoSelecionada !== null &&
           index === opcaoSelecionada &&
           index !== pergunta.respostaCerta
           ) {
            estiloBotao = styles.botaoErrado;
         }
          return (
            <TouchableOpacity
              key={index}
              disabled={botoesBloqueados}
              style={[styles.botaoOpcao, estiloBotao]}
              onPress={() => responder(index)}
            >
              <Text style={styles.textoOpcao}>
                {opcao}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 20,
    paddingTop: 60
  },

  telaCentrada: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },

  logoInicial: {
    width: 120,
    height: 120,
    marginBottom: 20
  },

  tituloPrincipal: {
    fontSize: 34,
    fontWeight: '900',
    color: '#1e293b',
    textAlign: 'center'
  },

  subtituloInicio: {
    fontSize: 16,
    textAlign: 'center',
    color: '#64748b',
    marginTop: 10,
    marginBottom: 40
  },

  botaoIniciar: {
    backgroundColor: '#10b981',
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 15
  },

  textoBotaoIniciar: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold'
  },

  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20
  },

  progresso: {
    fontWeight: 'bold'
  },

  pontos: {
    fontWeight: 'bold',
    color: '#2563eb'
  },

  cartaoPergunta: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    marginBottom: 20
  },

  imagemPergunta: {
    width: '100%',
    height: 180,
    borderRadius: 12,
    marginBottom: 15
  },

  textoPergunta: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center'
  },

  areaOpcoes: {
    flex: 1
  },

  botaoOpcao: {
    backgroundColor: '#fff',
    padding: 18,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0'
  },

  botaoCorreto: {
    backgroundColor: '#22c55e',
    borderColor: '#22c55e'
  },

  botaoErrado: {
    backgroundColor: '#ef4444',
    borderColor: '#ef4444'
  },

  textoOpcao: {
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '600'
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 10
  },

  subtitulo: {
    fontSize: 18,
    marginBottom: 30,
    textAlign: 'center'
  },

  botaoAcao: {
    backgroundColor: '#2563eb',
    paddingVertical: 15,
    paddingHorizontal: 35,
    borderRadius: 12
  },

  textoBotaoAcao: {
    color: '#fff',
    fontWeight: 'bold'
  },

  textoCarregando: {
    marginTop: 15,
    fontSize: 16
  }
});
